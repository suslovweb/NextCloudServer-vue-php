OC.L10N.register(
    "activity",
    {
    "Today" : "ថ្ងៃ​នេះ",
    "Personal activity feed for %s" : "សកម្មភាព feed ផ្ទាល់​ខ្លួន​សម្រាប់ %s",
    "Your settings have been updated." : "ការ​កំណត់​របស់​អ្នក​ត្រូវ​បាន​ធ្វើ​បច្ចុប្បន្នភាព។",
    "Hello %s," : "សួស្ដី %s,",
    "Mail" : "សំបុត្រ",
    "Activity" : "សកម្មភាព",
    "Notifications" : "ការ​ជូន​ដំណឹង",
    "Activity feed" : "សកម្មភាព feed",
    "You need to set up your email address before you can receive notification emails." : "អ្នក​ចាំបាច់​ត្រូវតែដំឡើង​អាសយដ្ឋាន​អ៊ីមែលរបស់អ្នកមុនពេល​ដែលអ្នកអាចទទួលបានការជូន​ដំណឹង​ទៅកាន់​អ៊ីមែល ។",
    "Hourly" : "រាល់​ម៉ោង",
    "Daily" : "រាល់ថ្ងៃ",
    "Weekly" : "រាល់​សប្ដាហ៍",
    "Settings" : "ការកំណត់",
    "Enable RSS feed" : "បើក RSS feed",
    "No more events to load" : "គ្មាន​ព្រឹត្តិការណ៍​ផ្សេងទៀត​បើក​ដំណើរការទេ"
},
"nplurals=1; plural=0;");

OC.L10N.register(
    "activity",
    {
    "Home" : "Baş sahypa",
    "Today" : "Şu gün",
    "Yesterday" : "Düýn",
    "Hello %s" : "Salam%s",
    "Settings" : "Sazlamalar"
},
"nplurals=2; plural=(n != 1);");

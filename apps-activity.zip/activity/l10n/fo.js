OC.L10N.register(
    "activity",
    {
    "Copied!" : "Kopiera!",
    "Press ⌘-C to copy." : "Trýst ⌘-C fyri at kopiera.",
    "Press Ctrl-C to copy." : "Trýst Ctrl-C fyri at kopiera.",
    "Home" : "Heim",
    "in {path}" : "í {path}",
    "Today" : "Ídag",
    "Yesterday" : "Ígjár",
    "All activities" : "Alt virksemi",
    "Hello %s" : "Hey %s",
    "Hello %s," : "Hey %s,",
    "Mail" : "Post",
    "Activity" : "Virksemi",
    "As soon as possible" : "So skjótt sum gjørligt",
    "Hourly" : "Hvønn tíma",
    "Daily" : "Hvønn dag",
    "Weekly" : "Hvørja viku"
},
"nplurals=2; plural=(n != 1);");

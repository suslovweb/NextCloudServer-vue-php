OC.L10N.register(
    "activity",
    {
    "Home" : "அகம்",
    "Today" : "இன்று",
    "Yesterday" : "நேற்று",
    "Open {filename}" : "திற {கோப்பின் பெயர்}",
    "Your settings have been updated." : "உங்களின் அமைப்புகள் சேமிக்கப்பட்டன",
    "Settings have been updated." : "அமைப்புகள் சேமிக்கப்பட்டன.",
    "Recent activity" : "அண்மைச் செயல்பாடுகள்",
    "Daily activity summary for %s" : "%s-ன் அன்றாட செயல்பாட்டுச் சுருக்கம்",
    "All activities" : "அனைத்து செயல்பாடுகள்",
    "By others" : "மற்றவர்களால்",
    "By you" : "உங்களால் ",
    "Hello %s" : "வணக்கம் %s",
    "Hello %s," : "வணக்கம் %s,",
    "Settings" : "அமைப்புகள்"
},
"nplurals=2; plural=(n != 1);");

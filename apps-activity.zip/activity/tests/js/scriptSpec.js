/*
 * Copyright (c) 2015
 *
 * This file is licensed under the Affero General Public License version 3
 * or later.
 *
 * See the COPYING-README file.
 *
 */
describe('Filter', function() {
	it('tests something', function() {
		// TODO: implement proper tests
	});
});

describe('Infinite scrolling', function() {
	// TODO: implement proper tests
});


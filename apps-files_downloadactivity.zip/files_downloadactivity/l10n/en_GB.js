OC.L10N.register(
    "files_downloadactivity",
    {
    "Downloaded by {actor} (via desktop)" : "Downloaded by {actor} (via desktop)",
    "Downloaded by {actor} (via app)" : "Downloaded by {actor} (via app)",
    "Downloaded by {actor} (via browser)" : "Downloaded by {actor} (via browser)",
    "Shared file {file} was downloaded by {actor} via the desktop client" : "Shared file {file} was downloaded by {actor} via the desktop client",
    "Shared file {file} was downloaded by {actor} via the mobile app" : "Shared file {file} was downloaded by {actor} via the mobile app",
    "Shared file {file} was downloaded by {actor} via the browser" : "Shared file {file} was downloaded by {actor} via the browser",
    "A local shared file or folder was <strong>downloaded</strong>" : "A local shared file or folder was <strong>downloaded</strong>",
    "Activities for shared file downloads" : "Activities for shared file downloads",
    "Creates activities for downloads of files that were shared with other users or a group" : "Creates activities for downloads of files that were shared with other users or a group"
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "files_downloadactivity",
    {
    "Downloaded by {actor} (via desktop)" : "Преземено од {actor} (преку компјутер)",
    "Downloaded by {actor} (via app)" : "Преземено од {actor} (преку апликација)",
    "Downloaded by {actor} (via browser)" : "Преземено од {actor} (преку прелистувач)",
    "Shared file {file} was downloaded by {actor} via the desktop client" : "Споделената датотека {file} е преземена од {actor} преку клиент за компјутер",
    "Shared file {file} was downloaded by {actor} via the mobile app" : "Споделената датотека {file} е преземена од {actor} преку мобилна апликација",
    "Shared file {file} was downloaded by {actor} via the browser" : "Споделената датотека {file} е преземена од {actor} преку прелистувач",
    "A local shared file or folder was <strong>downloaded</strong>" : "Локално споделена датотека или папка е <strong>преземена</strong>",
    "Activities for shared file downloads" : "Активности за преземање на споделени датотеки",
    "Creates activities for downloads of files that were shared with other users or a group" : "Создава активности за преземени датотеки што се споделени со други корисници или група"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");

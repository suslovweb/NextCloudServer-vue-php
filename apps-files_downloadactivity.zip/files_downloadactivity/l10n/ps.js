OC.L10N.register(
    "files_downloadactivity",
    {
    "Downloaded by {actor} (via desktop)" : "شسیبشسیب"
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "files_downloadactivity",
    {
    "Downloaded by {actor} (via desktop)" : "Telecargat per {actor} (via desktop)",
    "Downloaded by {actor} (via app)" : "Telecargat per {actor} (via app)"
},
"nplurals=2; plural=(n > 1);");

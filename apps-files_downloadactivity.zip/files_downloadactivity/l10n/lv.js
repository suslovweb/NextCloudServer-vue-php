OC.L10N.register(
    "files_downloadactivity",
    {
    "Downloaded by {actor} (via desktop)" : "Lejupielādēja {actor} (izmantojot darbavirsmu)",
    "Shared file {file} was downloaded by {actor} via the desktop client" : "Koplietoto datni {file} lejupielādēja {actor} izmantojot darbavirsmas klientu",
    "A local shared file or folder was <strong>downloaded</strong>" : "Koplietotā datne vai mape tika <strong>lejupielādēta</strong>",
    "Activities for shared file downloads" : "Darbības koplietotās datnes lejupielādei"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");

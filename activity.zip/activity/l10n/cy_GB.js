OC.L10N.register(
    "activity",
    {
    "Home" : "Cartref",
    "Today" : "Heddiw",
    "Yesterday" : "Ddoe",
    "Mail" : "E-bost",
    "Activity" : "Gweithred",
    "Notifications" : "Hysbysiadau",
    "No activity yet" : "Dim gweithred eto",
    "Settings" : "Gosodiadau"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");

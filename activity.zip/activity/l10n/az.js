OC.L10N.register(
    "activity",
    {
    "Home" : "Ev",
    "Today" : "Bu gün",
    "Yesterday" : "Dünən",
    "Personal activity feed for %s" : "%s üçün şəxsi fəaliyyətin ötürülməsi",
    "Your feed URL is invalid" : "Sizin URL ötürməniz yalnışdır",
    "Your settings have been updated." : "Sizin configləriniz yenilendi.",
    "Hello %s," : "Salam %s,",
    "Mail" : "Məktub",
    "Activity" : "Fəallıq",
    "Notifications" : "Xəbərdarlıqlar",
    "Activity feed" : "Fəaliyyətin ötürülməsi",
    "You need to set up your email address before you can receive notification emails." : "Xəbərdarlıq məktubları almazdan öncə, siz mail ünvanınızı təyin etməlisiniz.",
    "Hourly" : "Saatlıq",
    "Daily" : "Günlük",
    "Weekly" : "Həftəlik",
    "Settings" : "Quraşdırmalar",
    "Enable RSS feed" : "RSS ötürməsinin işə salinmaslı",
    "No more events to load" : "Yüklənə biləcək digər səbəb yoxdur"
},
"nplurals=2; plural=(n != 1);");

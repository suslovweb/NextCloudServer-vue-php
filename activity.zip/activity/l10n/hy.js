OC.L10N.register(
    "activity",
    {
    "Today" : "այսօր",
    "Yesterday" : "երեկ",
    "Mail" : "Փոստ",
    "Settings" : "կարգավորումներ"
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "activity",
    {
    "Copied!" : "Kopirano",
    "Home" : "Početna stranica",
    "Today" : "Danas",
    "Yesterday" : "Jučer",
    "Mail" : "E-Pošta",
    "Activity" : "Aktivnost",
    "Notifications" : "Notifikacija",
    "Hourly" : "Svakog sata",
    "Daily" : "Dnevno",
    "Weekly" : "Sedmično",
    "Settings" : "Podešavanja",
    "An error occurred while loading activities" : "Došlo je do greške prilikom učitavanja aktivnosti"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");

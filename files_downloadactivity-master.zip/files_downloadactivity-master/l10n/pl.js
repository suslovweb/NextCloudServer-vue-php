OC.L10N.register(
    "files_downloadactivity",
    {
    "Downloaded by {actor} (via desktop)" : "Pobrane przez {actor} (przez klienta desktopowego)",
    "Downloaded by {actor} (via app)" : "Pobrane przez {actor} (przez aplikację mobilną)",
    "Downloaded by {actor} (via browser)" : "Pobrane przez {actor} (przez przeglądarkę)",
    "Shared file {file} was downloaded by {actor} via the desktop client" : "Udostępniony plik {file} został pobrany przez {actor} za pośrednictwem klienta desktopowego",
    "Shared file {file} was downloaded by {actor} via the mobile app" : "Udostępniony plik {file} został pobrany przez {actor} za pośrednictwem aplikacji mobilnej",
    "Shared file {file} was downloaded by {actor} via the browser" : "Udostępniony plik {file} został pobrany przez {actor} za pośrednictwem przeglądarki",
    "A local shared file or folder was <strong>downloaded</strong>" : "Udostępniony plik lub katalog lokalny został <strong>pobrany</strong>",
    "Activities for shared file downloads" : "Aktywność pobrań udostępnionego pliku",
    "Creates activities for downloads of files that were shared with other users or a group" : "Gromadzi informacje związane z pobieraniem plików udostępnionych innym użytkownikom lub grupie"
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");

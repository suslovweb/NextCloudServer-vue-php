OC.L10N.register(
    "files_downloadactivity",
    {
    "Downloaded by {actor} (via desktop)" : "{actor}  (компьютероор)-р татагдсан. ",
    "Downloaded by {actor} (via app)" : "{actor}  (аппликэйшнээр) татагдсан. ",
    "Downloaded by {actor} (via browser)" : "{actor} (вебээр) -р татагдсан.",
    "Shared file {file} was downloaded by {actor} via the desktop client" : "Түгээлцсэн {file} {actor}  хэрэглэгчийн компьютероор татагдсан. ",
    "Shared file {file} was downloaded by {actor} via the mobile app" : "Түгээлцсэн {file}  {actor} хэрэглэгчийн гар утасаар татагдсан.",
    "Shared file {file} was downloaded by {actor} via the browser" : "Түгээлцсэн {file}  {actor} хэрэглэгчийн веб интерфейсээр татагдсан.",
    "A local shared file or folder was <strong>downloaded</strong>" : "Дотоод түгээлцсэн файл эсвэл хавтас амжилттай <strong>татагдлаа</strong>",
    "Activities for shared file downloads" : "Түгээлцсэн файлын татацуудын үйл ажилгаанууд"
},
"nplurals=2; plural=(n != 1);");
